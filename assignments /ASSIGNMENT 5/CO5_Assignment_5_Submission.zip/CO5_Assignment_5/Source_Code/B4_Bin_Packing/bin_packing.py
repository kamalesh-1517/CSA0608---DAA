def first_fit_decreasing(items,C):
    bins=[]; contents=[]
    for x in sorted(items,reverse=True):
        for i,used in enumerate(bins):
            if used+x<=C:
                bins[i]+=x;contents[i].append(x);break
        else:
            bins.append(x);contents.append([x])
    return contents,[C-x for x in bins]
def exact_min_bins(items,C):
    a=sorted(items,reverse=True);best=len(a);loads=[]
    def dfs(i):
        nonlocal best
        if len(loads)>=best:return
        if i==len(a):best=min(best,len(loads));return
        x=a[i];seen=set()
        for j,v in enumerate(loads):
            if v not in seen and v+x<=C:
                seen.add(v);loads[j]+=x;dfs(i+1);loads[j]-=x
        loads.append(x);dfs(i+1);loads.pop()
    dfs(0);return best
if __name__=="__main__":
    C=10;items=[6,6,6,4,4,4]
    bins,rem=first_fit_decreasing(items,C)
    print("Capacity",C,"workloads",items)
    for i,b in enumerate(bins,1):print("Server",i,b,"remaining",rem[i-1])
    print("FFD servers",len(bins),"exact minimum",exact_min_bins(items,C))
