from collections import Counter
def graph_coloring(g,m,order=None):
    n=len(g); order=list(range(n)) if order is None else order
    col=[-1]*n; s=Counter()
    def bt(d):
        s["nodes"]+=1; s["max_depth"]=max(s["max_depth"],d)
        if d==n: return True
        v=order[d]
        for c in range(m):
            s["attempts"]+=1
            if all(col[u]!=c for u in g[v]):
                col[v]=c
                if bt(d+1): return True
                col[v]=-1; s["backtracks"]+=1
            else: s["rejected"]+=1
        return False
    ok=bt(0)
    return ok,col if ok else None,dict(s)
def graph(n,edges):
    g=[set() for _ in range(n)]
    for a,b in edges:g[a].add(b);g[b].add(a)
    return g
if __name__=="__main__":
    tests=[
      ("5-cycle",graph(5,[(0,1),(1,2),(2,3),(3,4),(4,0)]),3),
      ("Triangle",graph(3,[(0,1),(1,2),(2,0)]),2),
      ("Empty graph",graph(4,[]),1)]
    for name,g,m in tests:
        print(name,"m=",m,"input-order",graph_coloring(g,m))
    # Compare original order with descending-degree order on the same graphs.
    g=graph(6,[(0,1),(0,2),(0,3),(0,4),(0,5),(1,2),(2,3),(3,4),(4,5)])
    deg_order=sorted(range(len(g)),key=lambda v:len(g[v]),reverse=True)
    print("Ordering comparison graph:")
    print("Version 1 input order:",graph_coloring(g,3))
    print("Version 2 descending degree:",graph_coloring(g,3,deg_order))
