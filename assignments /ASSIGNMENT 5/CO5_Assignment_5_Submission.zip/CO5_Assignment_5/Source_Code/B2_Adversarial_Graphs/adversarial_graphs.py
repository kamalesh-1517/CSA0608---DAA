from graph_coloring import graph,graph_coloring
if __name__=="__main__":
    path=graph(8,[(i,i+1) for i in range(7)])
    k4=graph(4,[(i,j) for i in range(4) for j in range(i+1,4)])
    print("Graph A - 8 vertex path, m=3:",graph_coloring(path,3))
    print("Graph B - K4, m=3:",graph_coloring(k4,3))
