from itertools import combinations
def exact(U,C):
    for k in range(len(C)+1):
        checked=0
        for ids in combinations(range(len(C)),k):
            checked+=1
            covered=set().union(*(C[i] for i in ids)) if ids else set()
            if U<=covered:return list(ids),checked
    return None,checked
def greedy(U,C):
    left=set(U); chosen=[]; steps=0
    while left:
        gains=[(len(left & s),i) for i,s in enumerate(C) if i not in chosen]
        gain,i=max(gains,default=(0,None)); steps+=len(gains)
        if not gain:return None,steps
        chosen.append(i);left-=C[i]
    return chosen,steps
if __name__=="__main__":
    cases=[
      (set("ABCDEF"),[set("ABC"),set("DEF"),set("AD"),set("BE"),set("CF")]),
      (set("ABCDE"),[set("AB"),set("CD"),set("E"),set("ABC"),set("DE")]),
      (set("WXYZ"),[set("WX"),set("YZ"),set("WY"),set("XZ")])]
    for j,(u,c) in enumerate(cases,1):
        e,ec=exact(u,c);g,gs=greedy(u,c)
        print("Case",j,"exact size",len(e),"greedy size",len(g),"exact combinations",ec,"greedy gain checks",gs)
    # Greedy counterexample: greedy picks A (5), then D and E; optimum B+C.
    u=set(range(1,9));c=[{1,2,3,4,5},{1,2,6,7},{3,4,5,8},{6,7},{8}]
    e,_=exact(u,c);g,_=greedy(u,c)
    print("Counterexample exact:",[i+1 for i in e],"size",len(e))
    print("Counterexample greedy:",[i+1 for i in g],"size",len(g))
