# CO5 Assignment 5 – Search, Complexity and Approximation Engineering
Student: S. Kamalesh | Register No.: 192521013 | CSA06 Design and Analysis of Algorithms

- Report/: Word and PDF reports.
- Source_Code/A_Pseudocode/: language-independent pseudocode for Part A.
- Source_Code/B1_Graph_Colouring/: instrumented graph-colouring implementation.
- Source_Code/B2_Adversarial_Graphs/: same-colour-limit graph experiments.
- Source_Code/B3_Set_Cover/: exact and greedy set-cover implementations and counterexample.
- Source_Code/B4_Bin_Packing/: First-Fit Decreasing and small exact validator.
- Results/: captured console outputs.

Run with Python 3. For B2, set PYTHONPATH to the B1_Graph_Colouring folder or run from that folder.
