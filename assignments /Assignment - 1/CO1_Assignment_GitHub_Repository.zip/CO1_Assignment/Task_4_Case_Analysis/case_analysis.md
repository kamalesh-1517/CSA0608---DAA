# Task 4 – Case Analysis
| Algorithm | Best | Average | Worst |
|---|---|---|---|
| Linear | Θ(1), first key | Θ(n), uniform hit/miss | Θ(n), last or absent |
| Binary | Θ(1), middle key | Θ(log n) | Θ(log n) |
| Hash | Θ(1) | Expected Θ(1) | Θ(n), severe collisions |
