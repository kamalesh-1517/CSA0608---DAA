# Task 9 – Experimental Performance
See benchmark_results.csv, the time and operation graphs in Report/Tables_and_Graphs, and the rendered console output image in Report/Output_Screenshots/benchmark_output.png. Timings are machine-specific; preprocessing is recorded separately.
