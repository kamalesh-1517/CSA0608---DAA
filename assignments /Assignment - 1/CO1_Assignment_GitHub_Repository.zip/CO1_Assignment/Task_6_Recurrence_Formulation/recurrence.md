# Task 6 – Recurrence Formulation
Binary search makes one recursive call on at most floor(n/2) keys after constant outside work. Base cases are empty or one-element intervals. T(n)=T(floor(n/2))+c for n>1; T(0)=T(1)=d.
