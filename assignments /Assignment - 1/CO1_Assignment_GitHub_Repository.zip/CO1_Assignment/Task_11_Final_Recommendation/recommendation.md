# Task 11 – Final Recommendation
Recommend a hash index or database-native indexed key for exact registration-number lookup: expected Θ(1) lookup and lowest measured query time. Binary search remains useful for ordered/range queries. Linear search is unsuitable at one million records. Hashing uses Θ(n) extra memory and requires index maintenance.
