# CO1 Assignment – Student Record Search Strategy

## Project
Design, analysis and experimental validation of three student-registration-number search strategies for CSA06 Design and Analysis of Algorithms (CO1).

## Algorithms
1. Iterative linear search – O(n), no preprocessing.
2. Recursive binary search – O(log n) search after sorting; sorting costs O(n log n).
3. Hash-table lookup – expected O(1) lookup, O(n) index construction and space; worst-case O(n) lookup.

## Run
Requirements: Python 3.10+ (standard library only for the benchmark).
```bash
cd Task_8_Implementation_Testing/Source_Code
python search_benchmark.py
```
The program creates `benchmark_results.csv` in `Task_8_Implementation_Testing/`. A copy of the measured results is included at the repository root and under `Task_9_Experimental_Performance/`.

## Report
Open `Report/CO1_Assignment_Report.docx`. It includes all twelve tasks, mathematical derivations, recurrence solution, experimental tables, graphs, theory-versus-experiment discussion, recommendation and Day-4 design challenge.

## Repository Structure
- `Task_1_Algorithm_Design/` – algorithm descriptions and pseudocode (expanded in report).
- `Task_2_Basic_Operation/` – dominant operation analysis.
- `Task_3_Mathematical_Complexity/` – mathematical derivations.
- `Task_4_Case_Analysis/` – best/average/worst cases.
- `Task_5_Asymptotic_Analysis/` – asymptotic notation and interpretation.
- `Task_6_Recurrence_Formulation/` – binary-search recurrence.
- `Task_7_Recurrence_Solution/` – Master Theorem and iteration solution.
- `Task_8_Implementation_Testing/Source_Code/` – runnable Python source.
- `Task_9_Experimental_Performance/` – CSV and graphs.
- `Task_10_Theory_vs_Experiment/` – comparison.
- `Task_11_Final_Recommendation/` – recommendation.
- `Task_12_Design_Challenge/` – 50,000 searches/hour analysis.
- `Report/` – report, graphs, analysis and evidence folders.

## Experimental Method
Four deterministic datasets (1,000; 10,000; 100,000; 1,000,000 keys) and 100 mixed queries per size (50 hits, 50 misses) are used. All algorithms receive the same query set. Timing uses `time.perf_counter()`. Search time and preprocessing time are reported separately. The hash operation metric counts abstract dictionary lookups, not internal hash probes.

## Important
Measured times depend on machine, Python version and runtime conditions. For a formal submission, include screenshots from your own IDE/terminal if required and push the repository to your own GitHub account. No GitHub account or repository was accessed or modified by this generated package.
