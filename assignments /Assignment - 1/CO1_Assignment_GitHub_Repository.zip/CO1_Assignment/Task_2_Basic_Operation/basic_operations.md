# Task 2 – Basic Operations
Linear: equality comparison A[i]==x, repeated per visited record. Binary: middle-key comparison, with one half discarded per recursive call. Hash: hash computation and bucket/key lookup; benchmark counts one abstract Python dictionary lookup because internal probes are not exposed.
