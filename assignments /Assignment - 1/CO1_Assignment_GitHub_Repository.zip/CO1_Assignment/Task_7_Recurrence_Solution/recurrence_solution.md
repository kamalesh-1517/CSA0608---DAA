# Task 7 – Recurrence Solution
Master theorem: a=1, b=2, f(n)=Θ(1), and n^(log_b a)=1, so Case 2 gives Θ(log n). Iteration: T(n)=T(n/2)+c=T(n/4)+2c=...+jc. Stop at n/2^j≤1, hence j=Θ(log n), so T(n)=Θ(log n).
