# Task 8 – Implementation and Testing
Run `python Source_Code/search_benchmark.py`. Four dataset sizes: 1,000, 10,000, 100,000 and 1,000,000. Each size uses 100 queries (50 hits, 50 misses) with identical query sequence across approaches. Execution time, operation count and preprocessing time are recorded. Source code: Source_Code/search_benchmark.py.
