# Task 1 – Algorithm Design

## Iterative linear search
```text
LINEAR-SEARCH(A, x):
  for i = 0 to length(A)-1:
    if A[i] == x: return FOUND
  return NOT-FOUND
```
Sequentially scans unsorted keys; no preprocessing.

## Recursive binary search
```text
BINARY-SEARCH(A, x, low, high):
  if low > high: return NOT-FOUND
  mid = floor((low+high)/2)
  if A[mid] == x: return FOUND
  if x < A[mid]: return BINARY-SEARCH(A,x,low,mid-1)
  return BINARY-SEARCH(A,x,mid+1,high)
```
Requires sorted keys; each call halves the range.

## Hash-table lookup
```text
BUILD(records): H = empty hash table; insert each record by registration number
SEARCH(H,x): if x in H return H[x], else NOT-FOUND
```
Expected constant-time exact-key lookup after linear-time index construction.
