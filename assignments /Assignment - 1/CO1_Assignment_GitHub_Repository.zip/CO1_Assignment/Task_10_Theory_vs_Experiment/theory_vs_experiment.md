# Task 10 – Theory versus Experiment
Linear operation counts rise with n; binary comparisons grow logarithmically; hash lookup is one abstract dictionary operation per request. Timing differences also reflect interpreter, caching, memory and scheduling. Preprocessing costs must be included in overall design decisions.
