# Task 5 – Asymptotic Analysis
Linear best Ω(1), average Θ(n), worst O(n). Binary Θ(log n) search after Θ(n log n) sorting. Hash expected Θ(1), worst O(n), extra space Θ(n). Across 1,000 to 1,000,000 records, linear worst-case grows about 1,000×, binary depth about 10 to 20, hash expected lookup remains constant-order.
