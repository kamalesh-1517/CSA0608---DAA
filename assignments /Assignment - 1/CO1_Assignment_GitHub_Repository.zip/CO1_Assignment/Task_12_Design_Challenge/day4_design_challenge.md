# Task 12 – Day-4 Design Challenge
50,000 requests/hour = 13.89 requests/second average and 1.2 million/day. Daily-only additions allow batch index maintenance. Use a persistent database as source of truth with a hash/database index. Expected build Θ(n), lookup Θ(1), space Θ(n). Load-test bursts and monitor p95/p99 latency; B-tree is useful if ordered/range queries matter.
