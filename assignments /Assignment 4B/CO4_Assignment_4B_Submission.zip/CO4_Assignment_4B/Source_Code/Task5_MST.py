import heapq
def kruskal(n,E):
 p=list(range(n))
 def f(x):
  if p[x]!=x:p[x]=f(p[x])
  return p[x]
 out=[];trace=[]
 for u,v,w in sorted(E,key=lambda z:z[2]):
  a,b=f(u),f(v)
  if a!=b:p[a]=b;out.append((u,v,w));trace.append(("accept",u,v,w))
  else:trace.append(("reject",u,v,w))
 return out,trace
def prim(n,E):
 g=[[] for _ in range(n)]
 for u,v,w in E:g[u].append((w,u,v));g[v].append((w,v,u))
 seen={0};q=g[0][:];heapq.heapify(q);out=[];tr=[]
 while q and len(seen)<n:
  w,u,v=heapq.heappop(q)
  if v in seen:tr.append(("skip",u,v,w));continue
  seen.add(v);out.append((u,v,w));tr.append(("accept",u,v,w))
  for z in g[v]:
   if z[2] not in seen:heapq.heappush(q,z)
 return out,tr
def boruvka(n,E):
 p=list(range(n));out=[];tr=[]
 def f(x):
  if p[x]!=x:p[x]=f(p[x])
  return p[x]
 while len({f(i) for i in range(n)})>1:
  best={}
  for u,v,w in E:
   a,b=f(u),f(v)
   if a!=b:
    if a not in best or w<best[a][2]:best[a]=(u,v,w)
    if b not in best or w<best[b][2]:best[b]=(u,v,w)
  for u,v,w in best.values():
   a,b=f(u),f(v)
   if a!=b:p[a]=b;out.append((u,v,w));tr.append(("accept",u,v,w))
 return out,tr
if __name__=="__main__":
 E=[(0,1,4),(0,2,4),(1,2,2),(1,3,5),(2,3,5),(2,4,11),(3,4,2),(3,5,6),(4,5,1),(1,5,10)]
 for name,fn in [("Kruskal",kruskal),("Prim",prim),("Boruvka",boruvka)]:
  c,tr=fn(6,E);print(name,"trace",tr,"MST",c,"cost",sum(x[2] for x in c))
 tie=[(0,1,1),(1,2,1),(2,3,1),(3,0,1),(0,2,1),(1,3,1)]
 print("Equal-weight multiple-MST test")
 for name,fn in [("Kruskal",kruskal),("Prim",prim),("Boruvka",boruvka)]:
  c,_=fn(4,tie);print(name,c,sum(x[2] for x in c))
