def solve(words,W):
 n=len(words); dp=[10**18]*(n+1); nxt=[-1]*(n+1); dp[n]=0
 for i in range(n-1,-1,-1):
  used=0
  for j in range(i,n):
   used+=len(words[j])+(j>i)
   if used>W: break
   slack=W-used; cost=(0 if j==n-1 else slack**2)+dp[j+1]
   if cost<dp[i]: dp[i]=cost; nxt[i]=j+1
 if nxt[0]<0: raise ValueError("A word exceeds the line width")
 lines=[]; i=0
 while i<n:
  j=nxt[i]; line=words[i:j]; slack=W-sum(map(len,line))-len(line)+1
  lines.append((line,slack,0 if j==n else slack**2)); i=j
 return dp,lines
if __name__=="__main__":
 words="Dynamic programming creates efficient solutions for document layout systems".split()
 for W in (16,20,24):
  dp,lines=solve(words,W); print("\\nWIDTH",W,"MIN PENALTY",dp[0],"DP SUFFIX",dp)
  for k,(line,s,p) in enumerate(lines,1): print("Line",k,":"," ".join(line),"unused",s,"penalty",p)
 try: solve(["extraordinary"],8)
 except ValueError as e: print("Boundary test:",e)
