import heapq, math
def dij(g,s):
 d=[math.inf]*len(g);p=[None]*len(g);done=[];d[s]=0;q=[(0,s)]
 while q:
  du,u=heapq.heappop(q)
  if du!=d[u]:continue
  done.append(u)
  for v,w in g[u]:
   if w<0:raise ValueError("Dijkstra requires non-negative weights")
   if d[v]>du+w:d[v]=du+w;p[v]=u;heapq.heappush(q,(d[v],v))
 return d,p,done
def bf(n,E,s):
 d=[math.inf]*n;p=[None]*n;d[s]=0
 for _ in range(n-1):
  change=False
  for u,v,w in E:
   if d[u]!=math.inf and d[u]+w<d[v]:d[v]=d[u]+w;p[v]=u;change=True
  if not change:break
 neg=[(u,v) for u,v,w in E if d[u]!=math.inf and d[u]+w<d[v]]
 return d,p,neg
def closure(n,E,weighted=False):
 d=[[math.inf]*n for _ in range(n)]
 for i in range(n):d[i][i]=0
 for u,v,w in E:d[u][v]=min(d[u][v],w)
 for k in range(n):
  for i in range(n):
   for j in range(n):d[i][j]=min(d[i][j],d[i][k]+d[k][j])
 return d
def warshall(n,E):
 r=[[i==j for j in range(n)] for i in range(n)]
 for u,v,w in E:r[u][v]=True
 for k in range(n):
  for i in range(n):
   for j in range(n):r[i][j]|=r[i][k] and r[k][j]
 return r
if __name__=="__main__":
 n=8; E=[(0,1,4),(0,2,2),(1,2,1),(1,3,5),(2,3,8),(2,4,10),(3,4,2),(3,5,6),(4,5,3),(4,6,7),(5,6,1),(6,7,2),(5,7,5)]
 g=[[] for _ in range(n)]
 for u,v,w in E:g[u].append((v,w));g[v].append((u,w))
 d,p,done=dij(g,0); names="ABCDEFGH"
 def path(v):
  a=[]
  while v is not None:a.append(names[v]);v=p[v]
  return "-".join(a[::-1])
 print("Dijkstra finalised", [names[x] for x in done])
 for v in range(n):print("A to",names[v],d[v],path(v))
 # directed modified network; make the changed edge meaningful
 D=[(u,v,w) for u,v,w in E]+[(v,u,w) for u,v,w in E]
 D=[e for e in D if e[:2]!=(1,4)]+[(1,4,-6)]
 print("Prediction: negative edge violates Dijkstra precondition; use Bellman-Ford.")
 print("Bellman-Ford distances",bf(n,D,0)[0])
 cyc=D+[(4,1,-3)]
 print("Reachable negative cycle",bf(n,cyc,0)[2])
 print("Floyd matrix")
 for row in closure(n,D):print(["INF" if x==math.inf else int(x) for x in row])
 print("Warshall matrix")
 for row in warshall(n,D):print([int(x) for x in row])
