import itertools,time,tracemalloc
def held(cost):
 n=len(cost);dp={};par={}
 for j in range(1,n):dp[(1|1<<j,j)]=cost[0][j];par[(1|1<<j,j)]=0
 states=len(dp)
 for sz in range(3,n+1):
  for sub in itertools.combinations(range(1,n),sz-1):
   mask=1
   for x in sub:mask|=1<<x
   for j in sub:
    pm=mask^(1<<j);v,k=min((dp[(pm,k)]+cost[k][j],k) for k in sub if k!=j)
    dp[(mask,j)]=v;par[(mask,j)]=k;states+=1
 full=(1<<n)-1;best,last=min((dp[(full,j)]+cost[j][0],j) for j in range(1,n))
 route=[last];mask=full
 while last:
  prev=par[(mask,last)];mask^=1<<last;last=prev
  if last:route.append(last)
 return best,[0]+route[::-1]+[0],states
def brute(c):
 n=len(c);return min((sum(c[r[i]][r[i+1]] for i in range(n)),(0,)+r+(0,)) for r in itertools.permutations(range(1,n)))
def mat(n):return [[0 if i==j else ((i*7+j*11+3)%19)+1 for j in range(n)] for i in range(n)]
if __name__=="__main__":
 names=["Hub","A","B","C","D","E","F"]
 c=[[0,10,15,20,12,18,9],[10,0,35,25,17,28,14],[15,35,0,30,20,16,22],[20,25,30,0,11,19,24],[12,17,20,11,0,13,15],[18,28,16,19,13,0,10],[9,14,22,24,15,10,0]]
 best,r,s=held(c);print("Minimum",best,"route"," -> ".join(names[i] for i in r),"states",s)
 small=[row[:5] for row in c[:5]];print("Validation DP",held(small)[:2],"brute",brute(small))
 print("Growth: delivery points, states, ms, peak KB")
 for n in range(5,10):
  tracemalloc.start();t=time.perf_counter();ans,route,states=held(mat(n));ms=(time.perf_counter()-t)*1000;peak=tracemalloc.get_traced_memory()[1]/1024;tracemalloc.stop()
  print(n-1,states,round(ms,3),round(peak,1))
 print("200 locations: use nearest-neighbour + 2-opt/local search or metaheuristic; faster, but no global-optimum guarantee.")
