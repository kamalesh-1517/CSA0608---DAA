def solve(a,t,e,x,verbose=True):
 n=len(a[0]);f=[[0]*n for _ in range(2)];back=[[0]*n for _ in range(2)]
 f[0][0]=e[0]+a[0][0];f[1][0]=e[1]+a[1][0]
 for j in range(1,n):
  c0=f[0][j-1]+a[0][j];c1=f[1][j-1]+t[1][j-1]+a[0][j]
  d0=f[1][j-1]+a[1][j];d1=f[0][j-1]+t[0][j-1]+a[1][j]
  f[0][j]=min(c0,c1);back[0][j]=0 if c0<=c1 else 1
  f[1][j]=min(d0,d1);back[1][j]=1 if d0<=d1 else 0
  if verbose:print("Station",j+1,"L1 stay/transfer",c0,c1,"selected",f[0][j],"L2 stay/transfer",d0,d1,"selected",f[1][j])
 end=[f[0][-1]+x[0],f[1][-1]+x[1]];line=min(range(2),key=lambda z:end[z])
 route=[line]
 for j in range(n-1,0,-1):line=back[line][j];route.append(line)
 return min(end),route[::-1]
if __name__=="__main__":
 a=[[7,9,3,4,8,4],[8,5,6,4,5,7]];t=[[2,3,1,3,4],[2,1,2,2,1]];e=[2,4];x=[3,2]
 print("Baseline");print("Result",solve(a,t,e,x))
 print("Prediction: raising transfer L1->L2 at station 3 may change route and cannot lower minimum time.")
 t2=[t[0][:],t[1][:]];t2[0][2]=20;print("Modified transfer",solve(a,t2,e,x,False))
 a2=[a[0][:],a[1][:]];a2[0][2]=20;print("Station disruption",solve(a2,t,e,x,False))
 print("Three lines: state f[line][station]; compare staying with transfers from each of the other two lines; store predecessor line.")
