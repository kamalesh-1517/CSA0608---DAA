def fractional(items,C):
 chosen=[]; total=0
 for ident,w,v in sorted(items,key=lambda z:z[2]/z[1],reverse=True):
  f=min(1,C/w)
  if f<=0: break
  chosen.append((ident,f)); total+=f*v; C-=f*w
 return total,chosen
def zero_one(items,C):
 n=len(items); d=[[0]*(C+1) for _ in range(n+1)]
 for i,(name,w,v) in enumerate(items,1):
  for c in range(C+1):
   d[i][c]=max(d[i-1][c],d[i-1][c-w]+v if w<=c else 0)
 ans=[];c=C
 for i in range(n,0,-1):
  if d[i][c]!=d[i-1][c]:
   name,w,v=items[i-1];ans.append(name);c-=w
 return d[n][C],ans,d
if __name__=="__main__":
 normal=[("A",10,60),("B",20,100),("C",30,120)]
 print("Normal fractional",fractional(normal,50));print("Normal 0/1",zero_one(normal,50)[:2])
 trap=[("X",10,60),("Y",6,40),("Z",5,30)];C=11;left=C;g=[];v=0
 for name,w,val in sorted(trap,key=lambda z:z[2]/z[1],reverse=True):
  if w<=left:g.append(name);left-=w;v+=val
 opt,sel,_=zero_one(trap,C)
 print("Counterexample capacity",C,"greedy",g,v,"DP",sel,opt)
 print("First blocking commitment: X leaves capacity 1; optimum is Y+Z.")
