# CO4 Assignment 4B – Algorithm Engineering
Student: S. Kamalesh | Register No. 192521013 | CSA06

Six Python implementations, Word/PDF reports, and captured console outputs are included. Run each source file with Python 3; no third-party packages are required.
