from __future__ import annotations
import math, random, time
from typing import List, Tuple

def max_min_dc(a, stats=None):
    if not a: raise ValueError("input must not be empty")
    if stats is None: stats={"comparisons":0}
    def solve(lo,hi):
        if lo==hi: return a[lo],a[lo]
        if hi-lo==1:
            stats["comparisons"]+=1
            return (a[lo],a[hi]) if a[lo]<a[hi] else (a[hi],a[lo])
        mid=(lo+hi)//2
        mn1,mx1=solve(lo,mid); mn2,mx2=solve(mid+1,hi)
        stats["comparisons"]+=2
        return min(mn1,mn2),max(mx1,mx2)
    return (*solve(0,len(a)-1),stats["comparisons"])

def max_min_independent(a):
    if not a: raise ValueError("input must not be empty")
    mn=mx=a[0]; c=0
    for x in a[1:]:
        c+=1
        if x<mn: mn=x
        c+=1
        if x>mx: mx=x
    return mn,mx,c

def binary_search(a,target):
    lo,hi=0,len(a)-1; c=0
    while lo<=hi:
        mid=(lo+hi)//2; c+=1
        if a[mid]==target: return mid,c
        if a[mid]<target: lo=mid+1
        else: hi=mid-1
    return -1,c

def merge_sort(a):
    if len(a)<=1: return a[:]
    m=len(a)//2
    l=merge_sort(a[:m]); r=merge_sort(a[m:])
    out=[]; i=j=0
    while i<len(l) and j<len(r):
        if l[i]<=r[j]: out.append(l[i]); i+=1
        else: out.append(r[j]); j+=1
    return out+l[i:]+r[j:]

def quick_sort(a, pivot="last"):
    maxdepth=0; partition_sizes=[]
    def rec(x,depth):
        nonlocal maxdepth
        maxdepth=max(maxdepth,depth)
        if len(x)<=1: return x
        p = x[-1] if pivot=="last" else x[len(x)//2]
        left=[v for v in x[:-1] if v<=p] if pivot=="last" else [v for i,v in enumerate(x) if i!=len(x)//2 and v<=p]
        right=[v for v in x[:-1] if v>p] if pivot=="last" else [v for i,v in enumerate(x) if i!=len(x)//2 and v>p]
        partition_sizes.append((len(left),len(right)))
        return rec(left,depth+1)+[p]+rec(right,depth+1)
    return rec(list(a),1),maxdepth,partition_sizes

def karatsuba(x,y, counter=None):
    if counter is None: counter={"multiplications":0}
    if x<10 or y<10:
        counter["multiplications"]+=1
        return x*y
    n=max(len(str(abs(x))),len(str(abs(y))))
    m=n//2; p=10**m
    a,b=divmod(x,p); c,d=divmod(y,p)
    z0=karatsuba(b,d,counter)
    z2=karatsuba(a,c,counter)
    z1=karatsuba(a+b,c+d,counter)-z2-z0
    return z2*p*p+z1*p+z0

def conventional_multiply(A,B):
    n=len(A); m=len(B[0]); k=len(B)
    C=[[0]*m for _ in range(n)]; mults=0
    for i in range(n):
        for j in range(m):
            for t in range(k):
                C[i][j]+=A[i][t]*B[t][j]; mults+=1
    return C,mults

def _add(A,B,sign=1):
    n=len(A); return [[A[i][j]+sign*B[i][j] for j in range(n)] for i in range(n)]
def _split(A):
    n=len(A); h=n//2
    return ([row[:h] for row in A[:h]],[row[h:] for row in A[:h]],
            [row[:h] for row in A[h:]],[row[h:] for row in A[h:]])
def _join(C11,C12,C21,C22):
    return [C11[i]+C12[i] for i in range(len(C11))]+[C21[i]+C22[i] for i in range(len(C21))]
def strassen(A,B,threshold=1,counter=None):
    if counter is None: counter={"multiplications":0}
    n=len(A)
    if n<=threshold:
        C=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j]+=A[i][k]*B[k][j]; counter["multiplications"]+=1
        return C
    a,b,c,d=_split(A); e,f,g,h=_split(B)
    M1=strassen(_add(a,d),_add(e,h),threshold,counter)
    M2=strassen(_add(c,d),e,threshold,counter)
    M3=strassen(a,_add(f,h,-1),threshold,counter)
    M4=strassen(d,_add(g,e,-1),threshold,counter)
    M5=strassen(_add(a,b),h,threshold,counter)
    M6=strassen(_add(c,a,-1),_add(e,f),threshold,counter)
    M7=strassen(_add(b,d,-1),_add(g,h),threshold,counter)
    C11=_add(_add(_add(M1,M4),M5,-1),M7)
    C12=_add(M3,M5)
    C21=_add(M2,M4)
    C22=_add(_add(_add(M1,M2,-1),M3),M6)
    return _join(C11,C12,C21,C22)
def strassen_any(A,B,threshold=1):
    n=len(A)
    if n!=len(A[0]) or n!=len(B) or n!=len(B[0]): raise ValueError("square matrices required")
    p=1
    while p<n: p*=2
    Ap=[row+[0]*(p-n) for row in A]+[[0]*p for _ in range(p-n)]
    Bp=[row+[0]*(p-n) for row in B]+[[0]*p for _ in range(p-n)]
    counter={"multiplications":0}
    Cp=strassen(Ap,Bp,threshold,counter)
    return [row[:n] for row in Cp[:n]],counter["multiplications"],p

def closest_pair_bruteforce(points):
    best=float("inf"); pair=None; count=0
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            count+=1; d=math.dist(points[i],points[j])
            if d<best: best=d; pair=(points[i],points[j])
    return best,pair,count
def closest_pair_dc(points):
    if len(points)<2: return float("inf"),None,0
    pts=sorted(points); px=pts; py=sorted(points,key=lambda p:p[1])
    def rec(x,y):
        n=len(x)
        if n<=3: return closest_pair_bruteforce(x)
        mid=n//2; midx=x[mid][0]
        dl,pl,cl=rec(x[:mid],sorted(x[:mid],key=lambda p:p[1]))
        dr,pr,cr=rec(x[mid:],sorted(x[mid:],key=lambda p:p[1]))
        d,pair=(dl,pl) if dl<dr else (dr,pr); count=cl+cr
        strip=[q for q in y if abs(q[0]-midx)<d]
        for i in range(len(strip)):
            j=i+1
            while j<len(strip) and strip[j][1]-strip[i][1]<d:
                count+=1; dd=math.dist(strip[i],strip[j])
                if dd<d: d=dd; pair=(strip[i],strip[j])
                j+=1
        return d,pair,count
    return rec(px,py)

def quickselect(a,k,pivot="random",rng=None):
    if not 0<=k<len(a): raise ValueError("k out of range")
    rng=rng or random.Random(7); x=list(a)
    while True:
        if len(x)<=1: return x[0]
        p=x[-1] if pivot=="last" else (x[rng.randrange(len(x))] if pivot=="random" else x[len(x)//2])
        lo=[v for v in x if v<p]; eq=[v for v in x if v==p]; hi=[v for v in x if v>p]
        if k<len(lo): x=lo
        elif k<len(lo)+len(eq): return p
        else: k-=len(lo)+len(eq); x=hi

def median_of_medians(a,k):
    if not 0<=k<len(a): raise ValueError("k out of range")
    x=list(a)
    def select(v,k):
        if len(v)<=5: return sorted(v)[k]
        groups=[sorted(v[i:i+5]) for i in range(0,len(v),5)]
        med=[g[len(g)//2] for g in groups]
        pivot=select(med,len(med)//2)
        lo=[z for z in v if z<pivot]; eq=[z for z in v if z==pivot]; hi=[z for z in v if z>pivot]
        if k<len(lo): return select(lo,k)
        if k<len(lo)+len(eq): return pivot
        return select(hi,k-len(lo)-len(eq))
    return select(x,k)

def subset_sum_mitm(nums,target):
    mid=len(nums)//2; left=nums[:mid]; right=nums[mid:]
    def sums(xs):
        out=[]
        for mask in range(1<<len(xs)):
            s=sum(xs[i] for i in range(len(xs)) if mask>>i&1)
            out.append((s,mask))
        return out
    L=sums(left); R=sums(right); Rvals={s for s,_ in R}
    found=next((s for s,_ in L if target-s in Rvals),None)
    return found is not None,len(L),len(R)

def count_inversions(a):
    def sort_count(x):
        if len(x)<=1: return x,0
        m=len(x)//2; l,cl=sort_count(x[:m]); r,cr=sort_count(x[m:])
        out=[]; i=j=0; c=cl+cr
        while i<len(l) and j<len(r):
            if l[i]<=r[j]: out.append(l[i]); i+=1
            else: out.append(r[j]); j+=1; c+=len(l)-i
        return out+l[i:]+r[j:],c
    return sort_count(list(a))
