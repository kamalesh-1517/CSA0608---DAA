import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
a=[12,3,5,7,4,19,26,1,9,15,2,8,6,11,10]
k=7
print("Selection data:",a,"k (1-based):",k)
print("Median of Medians:",median_of_medians(a,k-1))
print("QuickSelect (seeded random):",quickselect(a,k-1))
nums=[3,34,4,12,5,2]; target=9
print("Subset sum:",nums,"target:",target)
print("Meet-in-the-Middle found,left subsets,right subsets:",subset_sum_mitm(nums,target))
print("Full enumeration subsets:",2**len(nums))
