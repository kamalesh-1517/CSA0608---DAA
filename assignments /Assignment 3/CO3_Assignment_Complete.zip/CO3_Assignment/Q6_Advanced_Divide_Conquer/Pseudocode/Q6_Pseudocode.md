# Q6 Pseudocode

## Median of Medians
```
SELECT(A,k):
    if |A|<=5: return sorted(A)[k]
    split A into groups of at most 5; sort each; collect group medians
    pivot=SELECT(medians, middle index)
    partition A into <pivot, =pivot, >pivot
    recurse only into the partition containing rank k; otherwise return pivot
```
## Meet-in-the-Middle Subset Sum
```
SUBSET-SUM(nums,target):
    split nums into L and R
    enumerate all subset sums SL of L and SR of R
    sort/hash SR
    for s in SL:
        if target-s occurs in SR: return TRUE
    return FALSE
```
The two halves each generate about 2^(n/2) sums rather than enumerating all 2^n subsets in one search.
