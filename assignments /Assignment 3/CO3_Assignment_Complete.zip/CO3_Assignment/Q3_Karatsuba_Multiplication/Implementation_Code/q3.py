import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
x,y=12345678,87654321
counter={"multiplications":0}
ans=karatsuba(x,y,counter)
print("Operands:",x,y)
print("Karatsuba product:",ans,"verified:",ans==x*y)
print("Recursive single-digit multiplications:",counter["multiplications"])
print("Python built-in product:",x*y)
