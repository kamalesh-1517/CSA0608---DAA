# Q3 Karatsuba Pseudocode
```
KARATSUBA(x,y):
    if x or y is single digit: return x*y
    m=floor(max(number_of_digits(x),number_of_digits(y))/2)
    split x=a*10^m+b; y=c*10^m+d
    z0=KARATSUBA(b,d)
    z2=KARATSUBA(a,c)
    z1=KARATSUBA(a+b,c+d)-z2-z0
    return z2*10^(2m)+z1*10^m+z0
```
Three recursive multiplications replace four: (a+b)(c+d) supplies the cross term.
