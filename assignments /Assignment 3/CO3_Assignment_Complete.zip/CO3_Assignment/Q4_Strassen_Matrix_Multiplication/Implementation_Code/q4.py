import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
A=[[1,2,3],[4,5,6],[7,8,9]]
B=[[9,8,7],[6,5,4],[3,2,1]]
C,mc,p=strassen_any(A,B)
D,md=conventional_multiply(A,B)
print("Matrix size: 3x3 (padded to",p,"x",p,")")
print("Conventional result:",D,"scalar multiplications:",md)
print("Strassen result:",C,"scalar multiplications:",mc)
print("Correct:",C==D)
