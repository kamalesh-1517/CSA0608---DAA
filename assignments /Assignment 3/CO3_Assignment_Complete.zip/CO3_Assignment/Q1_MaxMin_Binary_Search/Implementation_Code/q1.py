import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
a=[7,2,9,1,5,8,3,6]
print("Q1 MAX/MIN input:",a)
print("D&C min,max,comparisons:",max_min_dc(a))
print("Independent min,max,comparisons:",max_min_independent(a))
s=sorted(a)
for key in (5,4):
    print(f"Binary search key={key}:",binary_search(s,key))
