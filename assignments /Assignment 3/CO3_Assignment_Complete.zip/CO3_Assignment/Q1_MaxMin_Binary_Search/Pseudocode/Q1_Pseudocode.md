# Q1 Pseudocode

## A. Divide-and-Conquer Maximum and Minimum
```
MAXMIN(A, low, high):
    if low = high: return (A[low], A[low])
    if high = low + 1:
        compare A[low], A[high]
        return (smaller, larger)
    mid = floor((low + high)/2)
    (minL,maxL) = MAXMIN(A,low,mid)
    (minR,maxR) = MAXMIN(A,mid+1,high)
    return (min(minL,minR), max(maxL,maxR))
```
Each recursive call returns exactly two values: its minimum and maximum. The combine step uses two comparisons.

## B. Binary Search
```
BINARY-SEARCH(A,key):
    low=0; high=n-1
    while low <= high:
        mid=floor((low+high)/2)
        if A[mid]=key: return mid
        if A[mid]<key: low=mid+1
        else: high=mid-1
    return NOT-FOUND
```
The sorted order proves that the half opposite the target's possible location can be discarded.
