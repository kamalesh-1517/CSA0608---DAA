import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
points=[(2,3),(12,30),(40,50),(5,1),(12,10),(3,4),(8,8),(9,9)]
b=closest_pair_bruteforce(points); d=closest_pair_dc(points)
print("Points:",points)
print("Brute force distance,pair,distance checks:",b)
print("Divide & conquer distance,pair,distance checks:",d)
