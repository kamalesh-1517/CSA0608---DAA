# Q5 Closest Pair Pseudocode
```
CLOSEST-PAIR(P):
    sort points by x and y
    if n<=3: return brute-force closest pair
    split at median x into L and R
    (dL,pL)=CLOSEST-PAIR(L); (dR,pR)=CLOSEST-PAIR(R)
    d=min(dL,dR); best=corresponding pair
    strip = points within distance d of dividing line, ordered by y
    for each strip point p:
        compare only following strip points whose y-gap < d
        update best and d
    return (d,best)
```
The planar packing argument bounds the number of relevant successors per point by a constant (commonly at most seven under the standard geometric partition), so the combine stage is linear.
