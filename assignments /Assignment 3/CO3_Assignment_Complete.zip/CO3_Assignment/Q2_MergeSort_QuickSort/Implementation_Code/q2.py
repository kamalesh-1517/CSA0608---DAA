import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
cases={"balanced":[4,2,6,1,3,5,7],"sorted_unbalanced":list(range(1,9))}
for name,a in cases.items():
    print("\n",name,"input:",a)
    print("Merge Sort:",merge_sort(a))
    q,depth,parts=quick_sort(a,"last")
    print("Quick Sort:",q,"max recursion depth:",depth,"partition sizes:",parts)
