# Q2 Pseudocode
```
MERGE-SORT(A):
    if |A| <= 1: return A
    split A into L and R
    L=MERGE-SORT(L); R=MERGE-SORT(R)
    return MERGE(L,R)       # linear merge

QUICK-SORT(A):
    if |A| <= 1: return A
    choose pivot = last element
    partition remaining values into L (<= pivot), R (> pivot)
    return QUICK-SORT(L) + [pivot] + QUICK-SORT(R)
```
Merge Sort guarantees halves of sizes floor(n/2), ceil(n/2). Last-element-pivot Quick Sort can produce 0:(n-1) partitions on sorted or reverse-sorted distinct data.
