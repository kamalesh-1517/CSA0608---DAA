# Experimental Notes

Q1 counts comparisons explicitly. Q2 records partition sizes and recursion depth for last-pivot Quick Sort; timing data is in CSV. Q3 verifies exact products and counts base multiplications. Q4 validates a 3x3 input padded to 4x4. Q5 records distance checks for identical inputs. Q6 checks selection and subset sum. Q7 compares O(n²) brute-force inversion counting with O(n log n) merge-based counting. Timings depend on the execution environment and should be regenerated locally.
