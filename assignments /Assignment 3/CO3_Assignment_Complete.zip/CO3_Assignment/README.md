# CO3 Assignment 3 – Divide and Conquer

Course: CSA06 Design and Analysis of Algorithms (CO3)
- Student A: S. Kamalesh (192521013)
- Student B: Yuvaraj (register number to be confirmed)

Contains Q1–Q7 pseudocode, Python implementations, output logs/screenshots, experimental CSVs/graphs, report and contribution record.

## Run from repository root
```bash
python Q1_MaxMin_Binary_Search/Implementation_Code/q1.py
python Q2_MergeSort_QuickSort/Implementation_Code/q2.py
python Q3_Karatsuba_Multiplication/Implementation_Code/q3.py
python Q4_Strassen_Matrix_Multiplication/Implementation_Code/q4.py
python Q5_Divide_Conquer_Closest_Pair/Implementation_Code/q5.py
python Q6_Advanced_Divide_Conquer/Implementation_Code/q6.py
python Q7_Day4_Design_Challenge/Implementation_Code/q7.py
```
Requires Python 3.10+. `common_algorithms.py` must stay at repository root.

**Q7 note:** The supplied handout specifies the six design stages but does not name a challenge problem. Count Inversions is selected and clearly documented as the pair's chosen challenge. The initial proposals are editable drafts; both students should personalize them to reflect their actual independent thinking. Confirm Yuvaraj's register number and actual contributions before submission.
