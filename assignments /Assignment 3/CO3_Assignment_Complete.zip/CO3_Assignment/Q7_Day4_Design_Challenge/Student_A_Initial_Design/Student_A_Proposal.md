# Student A – Initial Independent Proposal
Problem selected: count inversions in an array.
- Decomposition: split the array into left and right halves until singleton arrays.
- Base case: zero or one element has zero inversions.
- Subproblem information: each side returns its sorted sequence and inversion count.
- Combine: merge sorted halves; whenever a right value is smaller than the current left value, count all remaining left values as cross inversions.
- Expected recurrence: T(n)=2T(n/2)+O(n), hence O(n log n).
