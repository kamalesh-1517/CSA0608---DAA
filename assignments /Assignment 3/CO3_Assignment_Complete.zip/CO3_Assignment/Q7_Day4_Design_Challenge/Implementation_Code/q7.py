import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common_algorithms import *
a=[2,4,1,3,5]
sorted_a,count=count_inversions(a)
print("Input:",a)
print("Sorted result:",sorted_a)
print("Inversion count:",count)
