# Student B – Initial Independent Proposal
Problem selected: count inversions in an array.
- Decomposition: split by index into two approximately equal arrays.
- Base case: an array with at most one item is already sorted and has no inversion.
- Subproblem information: sorted halves plus each half's inversion count.
- Combine: merge the halves and count cross inversions using the number of unmerged elements in the left half whenever a right-side value is selected first.
- Validation idea: compare with an O(n²) pair-enumeration baseline on the same arrays.
