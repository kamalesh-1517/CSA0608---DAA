# Q7 Day-4 Design Challenge: Count Inversions

**Challenge selected for this submission:** Given an array, count pairs (i,j) such that i<j and A[i]>A[j]. The supplied assignment specifies the design stages but does not prescribe a particular challenge input/problem; this concrete D&C problem is therefore explicitly selected by the pair.

```
COUNT-INVERSIONS(A):
    if |A|<=1: return (A,0)
    split A into L and R
    (SL, cL)=COUNT-INVERSIONS(L)
    (SR, cR)=COUNT-INVERSIONS(R)
    merge SL and SR into sorted S
    when taking SR[j] before remaining SL[i], add |SL|-i
    return (S,cL+cR+cCross)
```
The returned information is a sorted subarray and its inversion count. The cross count is accumulated during merge.
