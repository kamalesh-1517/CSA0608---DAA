# Q7 Joint Design Record
## Agreement
Both proposals split by index, use a singleton/empty base case, return sorted data with a local count, and count cross-boundary inversions during merge.
## Difference
Student A emphasized recurrence and the merge-count invariant. Student B emphasized an independent O(n²) baseline and test validation.
## Strengths retained
The final algorithm combines A's recurrence reasoning with B's baseline validation. Duplicate values are handled correctly by using `<=` when choosing from the left; equal values are not inversions.
## Final design
Use merge-sort recursion. For each merge, if right[j] < left[i], then every remaining element left[i:] is greater than right[j], so add len(left)-i. Total count is left count + right count + cross count.
## Design limitations
The implementation assumes comparable values and O(n) auxiliary merge storage. It is not advantageous for tiny arrays where a simple quadratic loop has lower overhead.
