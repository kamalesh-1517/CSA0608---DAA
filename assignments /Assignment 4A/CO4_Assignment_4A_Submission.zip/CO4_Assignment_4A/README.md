# CO4 Assignment 4A – S. Kamalesh

Student: S. Kamalesh  
Register Number: 192521013  
Programme: B.Tech Information Technology

## Contents
- `Source_Code/Task_1` through `Source_Code/Task_6`: task-wise language-independent pseudocode, manual traces and design reasoning.
- `Report/CO4_Assignment_4A_Report.docx`: editable Word report.
- `Report/CO4_Assignment_4A_Report.pdf`: PDF report.

## Important instruction
The uploaded Assignment 4A brief states that this is not a programming assignment, that a compiler is not required, and that programming-language code will not be accepted as pseudocode (page 10). Therefore, the task folders contain pseudocode and design evidence, not executable C/C++/Java/Python programs.
