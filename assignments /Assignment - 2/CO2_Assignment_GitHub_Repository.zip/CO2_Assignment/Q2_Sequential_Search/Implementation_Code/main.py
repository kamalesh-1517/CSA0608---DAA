"""Q2: Sequential search of tool records."""
import time, json

def sequential_search(records, target):
    comparisons=0
    for index, record in enumerate(records):
        comparisons+=1
        if record["tool_id"]==target: return index, comparisons
    return -1, comparisons

def run():
    sizes=[10,100,1000,10000]
    rows=[]
    for n in sizes:
        records=[{"tool_id":f"T-{i:05d}","technician":f"TECH-{i%30:02d}","work_bay":i%8} for i in range(n)]
        for label,target in [("first",records[0]["tool_id"]),("middle",records[n//2]["tool_id"]),("last",records[-1]["tool_id"]),("missing","T-MISSING")]:
            t=time.perf_counter(); idx,c=sequential_search(records,target); elapsed=time.perf_counter()-t
            rows.append({"n":n,"case":label,"index":idx,"comparisons":c,"seconds":elapsed})
    print("Q2 SEQUENTIAL SEARCH RESULTS")
    for r in rows: print(f'n={r["n"]:5} {r["case"]:7} index={r["index"]:6} comparisons={r["comparisons"]:5} time={r["seconds"]:.7f}s')
    with open("../../Experimental_Data/q2_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
