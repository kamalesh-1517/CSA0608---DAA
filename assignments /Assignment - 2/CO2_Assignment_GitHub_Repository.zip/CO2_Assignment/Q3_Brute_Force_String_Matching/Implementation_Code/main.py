"""Q3: Naive brute-force string matching with character-comparison counter."""
import json, time

def brute_force_match(text, pattern):
    comparisons=0
    if pattern=="": return 0, comparisons
    for shift in range(len(text)-len(pattern)+1):
        j=0
        while j<len(pattern):
            comparisons+=1
            if text[shift+j]!=pattern[j]: break
            j+=1
        if j==len(pattern): return shift, comparisons
    return -1, comparisons

def run():
    cases=[
      ("early_match","SECURITY ALERT: failed login","SECURITY"),
      ("repetitive_near_match","A"*300+"B","A"*30+"C"),
      ("no_match","0123456789"*40,"XYZ"),
      ("pattern_longer","SHORT","A VERY LONG PATTERN")
    ]
    rows=[]
    for name,txt,pat in cases:
        t=time.perf_counter(); pos,c=brute_force_match(txt,pat); elapsed=time.perf_counter()-t
        rows.append({"case":name,"text_length":len(txt),"pattern_length":len(pat),"position":pos,"comparisons":c,"seconds":elapsed})
    print("Q3 BRUTE-FORCE STRING MATCHING")
    for r in rows: print(f'{r["case"]:22} n={r["text_length"]:4} m={r["pattern_length"]:3} pos={r["position"]:4} char_comparisons={r["comparisons"]:6} time={r["seconds"]:.7f}s')
    with open("../../Experimental_Data/q3_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
