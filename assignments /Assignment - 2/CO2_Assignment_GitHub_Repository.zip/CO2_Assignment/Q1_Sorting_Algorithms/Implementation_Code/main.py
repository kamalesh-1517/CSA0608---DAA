"""Q1: Sorting algorithms with operation counters. Run: python main.py"""
import random, time, json

def selection_sort(a):
    a=a.copy(); c=s=0
    for i in range(len(a)-1):
        m=i
        for j in range(i+1,len(a)):
            c+=1
            if a[j]<a[m]: m=j
        if m!=i: a[i],a[m]=a[m],a[i]; s+=1
    return a, c, s

def bubble_sort(a):
    a=a.copy(); c=s=0
    for end in range(len(a)-1,0,-1):
        changed=False
        for j in range(end):
            c+=1
            if a[j]>a[j+1]:
                a[j],a[j+1]=a[j+1],a[j]; s+=1; changed=True
        if not changed: break
    return a, c, s

def insertion_sort(a):
    a=a.copy(); c=m=0
    for i in range(1,len(a)):
        key=a[i]; j=i-1
        while j>=0:
            c+=1
            if a[j]>key:
                a[j+1]=a[j]; m+=1; j-=1
            else: break
        a[j+1]=key; m+=1
    return a, c, m

def run():
    rng=random.Random(42)
    base=list(range(200))
    cases={"already_sorted":base, "reverse_sorted":base[::-1],
           "nearly_sorted":base.copy(), "random":rng.sample(base,len(base)),
           "edge_empty":[], "edge_single":[7]}
    # Nearly sorted: swap four adjacent pairs only.
    for i in (20,60,100,160): cases["nearly_sorted"][i],cases["nearly_sorted"][i+1]=cases["nearly_sorted"][i+1],cases["nearly_sorted"][i]
    rows=[]
    for name,data in cases.items():
        for alg,fn in [("Selection",selection_sort),("Bubble",bubble_sort),("Insertion",insertion_sort)]:
            t=time.perf_counter(); out,c,m=fn(data); elapsed=time.perf_counter()-t
            assert out==sorted(data)
            rows.append({"case":name,"algorithm":alg,"n":len(data),"comparisons":c,"swaps_or_moves":m,"seconds":elapsed})
    print("Q1 SORTING RESULTS")
    for r in rows: print(f'{r["case"]:16} {r["algorithm"]:10} comparisons={r["comparisons"]:6} swaps/moves={r["swaps_or_moves"]:6} time={r["seconds"]:.6f}s')
    with open("../../Experimental_Data/q1_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
