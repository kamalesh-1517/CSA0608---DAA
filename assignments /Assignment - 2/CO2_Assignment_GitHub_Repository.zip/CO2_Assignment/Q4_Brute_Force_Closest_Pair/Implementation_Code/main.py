"""Q4: Brute-force closest pair; each unordered pair is checked once."""
import random, time, math, json

def closest_pair(points):
    best=float("inf"); pair=None; pairs=distances=0
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            pairs+=1; distances+=1
            d2=(points[i][0]-points[j][0])**2+(points[i][1]-points[j][1])**2
            if d2<best: best=d2; pair=(points[i],points[j])
    return pair, math.sqrt(best) if pair else None, pairs, distances

def run():
    rng=random.Random(7); rows=[]
    for n in [100,300,600,1000,2000]:
        pts=[(rng.random()*10000,rng.random()*10000) for _ in range(n)]
        t=time.perf_counter(); pair,d,pairs,dist=closest_pair(pts); elapsed=time.perf_counter()-t
        rows.append({"n":n,"pairs_examined":pairs,"distance_calculations":dist,"closest_distance":d,"seconds":elapsed})
    print("Q4 BRUTE-FORCE CLOSEST PAIR")
    for r in rows: print(f'n={r["n"]:5} pairs={r["pairs_examined"]:10} distance_calcs={r["distance_calculations"]:10} time={r["seconds"]:.5f}s')
    with open("../../Experimental_Data/q4_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
