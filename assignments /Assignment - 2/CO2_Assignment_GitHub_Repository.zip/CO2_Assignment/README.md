# CO2 Assignment – Assignment 2

**Course:** CSA06 – Design and Analysis of Algorithms

## Structure
For every question Q1–Q7:
- `Pseudocode/algorithm_pseudocode.txt` – separate algorithm steps
- `Implementation_Code/main.py` – independent executable Python implementation
- `Output_Screenshots/` – generated execution output and relevant visualizations

Other content:
- `Final_Report/CO2_Assignment_Report.docx` – report with architecture diagram, pseudocode for Q1–Q7, output images, complexity analysis and design challenge evaluation
- `Experimental_Data/` – raw JSON experiment results
- `Graphs/` – architecture and performance graphs

## Running the programs
Use Python 3.10+. Open each question's `Implementation_Code` folder and run:
`python main.py`

Q5 requires matplotlib: `python -m pip install matplotlib`.

The programs use deterministic test data or fixed random seeds. Timing varies by computer; compare operation counts as the primary metric. Execution-output images are rendered captures of actual program output.
