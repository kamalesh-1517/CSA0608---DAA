"""Q5: Brute-force convex hull using orientation / same-side test."""
import json, time, matplotlib.pyplot as plt

def orient(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def convex_hull(points):
    pts=list(dict.fromkeys(points))  # remove duplicate coordinates
    n=len(pts); edges=set(); tests=0
    if n<=1: return pts,0
    for i in range(n):
        for j in range(i+1,n):
            pos=neg=False
            for k in range(n):
                if k==i or k==j: continue
                tests+=1; v=orient(pts[i],pts[j],pts[k])
                if v>0: pos=True
                elif v<0: neg=True
                if pos and neg: break
            if not (pos and neg): edges.add((i,j))
    # For visual boundary, monotone chain orders vertices (the edge test remains brute-force).
    ordered=sorted(pts)
    def half(seq):
        h=[]
        for p in seq:
            while len(h)>=2 and orient(h[-2],h[-1],p)<=0: h.pop()
            h.append(p)
        return h
    lower=half(ordered); upper=half(ordered[::-1])
    hull=lower[:-1]+upper[:-1]
    return hull,tests

def run():
    cases={
      "interior_points":[(0,0),(4,0),(4,4),(0,4),(2,2),(1,2),(3,1),(2,3)],
      "collinear_duplicates":[(0,0),(2,0),(4,0),(4,4),(0,4),(2,2),(0,0),(1,1),(3,3)],
      "triangle":[(0,0),(5,0),(2,4),(2,1)]
    }
    rows=[]
    for name,pts in cases.items():
        t=time.perf_counter(); hull,tests=convex_hull(pts); elapsed=time.perf_counter()-t
        rows.append({"case":name,"points":len(pts),"unique_points":len(set(pts)),"hull_vertices":len(hull),"orientation_tests":tests,"seconds":elapsed})
        fig,ax=plt.subplots()
        x=[p[0] for p in hull+[hull[0]]] if hull else []; y=[p[1] for p in hull+[hull[0]]] if hull else []
        ax.scatter([p[0] for p in pts],[p[1] for p in pts]); 
        if hull: ax.plot(x,y,marker="o")
        ax.set_title(f"Q5 Convex Hull: {name}"); ax.set_xlabel("x"); ax.set_ylabel("y"); ax.grid(True)
        fig.savefig(f"../Output_Screenshots/{name}_hull.png",dpi=130,bbox_inches="tight"); plt.close(fig)
    print("Q5 BRUTE-FORCE CONVEX HULL")
    for r in rows: print(r)
    with open("../../Experimental_Data/q5_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
