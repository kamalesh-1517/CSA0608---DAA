"""Q6: Exhaustive 0/1 knapsack by enumerating every subset."""
import time, json

def exhaustive_knapsack(packages, capacity):
    best_value=0; best=[]; feasible=0; candidates=0
    n=len(packages)
    for mask in range(1<<n):
        candidates+=1; weight=value=0; chosen=[]
        for i,p in enumerate(packages):
            if mask & (1<<i):
                weight+=p["weight"]; value+=p["value"]; chosen.append(p["id"])
        if weight<=capacity:
            feasible+=1
            if value>best_value: best_value=value; best=chosen
    return best,best_value,candidates,feasible

def run():
    small=[{"id":"A","weight":2,"value":3},{"id":"B","weight":3,"value":4},{"id":"C","weight":4,"value":5},{"id":"D","weight":5,"value":8}]
    chosen,val,cand,feas=exhaustive_knapsack(small,8)
    print(f"Manual-verification instance capacity=8: chosen={chosen}, value={val}, candidates={cand}, feasible={feas}")
    rows=[]
    for n in [8,10,12,14,16,18]:
        pk=[{"id":str(i),"weight":(i%7)+1,"value":(i%11)+2} for i in range(n)]
        t=time.perf_counter(); chosen,val,cand,feas=exhaustive_knapsack(pk,25); elapsed=time.perf_counter()-t
        rows.append({"n":n,"candidates":cand,"feasible":feas,"best_value":val,"seconds":elapsed})
    print("Q6 EXHAUSTIVE SEARCH GROWTH")
    for r in rows: print(f'n={r["n"]:2} subsets={r["candidates"]:10} feasible={r["feasible"]:10} time={r["seconds"]:.5f}s')
    with open("../../Experimental_Data/q6_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
