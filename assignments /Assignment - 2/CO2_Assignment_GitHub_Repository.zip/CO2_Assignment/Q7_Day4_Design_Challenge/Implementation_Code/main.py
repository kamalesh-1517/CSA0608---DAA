"""Q7: Q4 redesign - divide-and-conquer closest pair with strip pruning."""
import random, time, math, json

def brute(points):
    best=float("inf"); pair=None; count=0
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            count+=1; d=(points[i][0]-points[j][0])**2+(points[i][1]-points[j][1])**2
            if d<best: best=d; pair=(points[i],points[j])
    return math.sqrt(best) if pair else None,count

def redesigned(points):
    px=sorted(points); py=sorted(points,key=lambda p:p[1]); count=0
    def rec(xs,ys):
        nonlocal count
        n=len(xs)
        if n<=3:
            best=float("inf")
            for i in range(n):
                for j in range(i+1,n):
                    count+=1; best=min(best,(xs[i][0]-xs[j][0])**2+(xs[i][1]-xs[j][1])**2)
            return best
        mid=n//2; midx=xs[mid][0]
        leftx=xs[:mid]; rightx=xs[mid:]
        leftset=set(leftx); lefty=[p for p in ys if p in leftset]; righty=[p for p in ys if p not in leftset]
        d2=min(rec(leftx,lefty),rec(rightx,righty))
        strip=[p for p in ys if (p[0]-midx)**2<d2]
        for i in range(len(strip)):
            j=i+1
            while j<len(strip) and (strip[j][1]-strip[i][1])**2<d2:
                count+=1
                d2=min(d2,(strip[j][0]-strip[i][0])**2+(strip[j][1]-strip[i][1])**2)
                j+=1
        return d2
    if len(points)<2: return None,0
    d2=rec(px,py); return math.sqrt(d2),count

def run():
    rng=random.Random(19); rows=[]
    for n in [100,200,400,800,1200]:
        pts=[(rng.random()*10000,rng.random()*10000) for _ in range(n)]
        t=time.perf_counter(); db,cb=brute(pts); tb=time.perf_counter()-t
        t=time.perf_counter(); dr,cr=redesigned(pts); tr=time.perf_counter()-t
        assert abs(db-dr)<1e-9
        rows.append({"n":n,"brute_comparisons":cb,"redesign_comparisons":cr,"brute_seconds":tb,"redesign_seconds":tr,"same_distance":abs(db-dr)<1e-9})
    print("Q7 ORIGINAL VS REDESIGNED CLOSEST PAIR")
    for r in rows: print(f'n={r["n"]:4} brute_ops={r["brute_comparisons"]:9} redesigned_ops={r["redesign_comparisons"]:8} brute={r["brute_seconds"]:.5f}s redesigned={r["redesign_seconds"]:.5f}s verified={r["same_distance"]}')
    with open("../../Experimental_Data/q7_results.json","w") as f: json.dump(rows,f,indent=2)
if __name__=="__main__": run()
